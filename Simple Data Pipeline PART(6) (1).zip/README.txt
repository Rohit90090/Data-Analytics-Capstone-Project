Student Level Data Project

This is a simple dbt project.

Data Flow:
CSV -> MySQL -> stg_orders -> int_customer_metrics -> mart_monthly_revenue -> Dashboard

Models:
1. stg_orders
- cleans order data
- standardizes dates

2. int_customer_metrics
- total_orders
- total_spend
- last_order_date

3. mart_monthly_revenue
- monthly revenue
- last month revenue
- revenue difference

Tests:
- unique customer_id
- not null order_date
- revenue > 0

Commands:
dbt run
dbt test

Dashboard:
Connect Power BI to mart_monthly_revenue.
