select
    order_id,
    customer_id,
    cast(order_date as date) as order_date,
    total_amount
from raw_transactions
where order_id is not null;
