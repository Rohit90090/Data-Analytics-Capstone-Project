select
    customer_id,
    count(order_id) as total_orders,
    sum(total_amount) as total_spend,
    max(order_date) as last_order_date
from {{ ref('stg_orders') }}
group by customer_id;
