with monthly_data as (
    select
        month(order_date) as month_no,
        sum(total_amount) as monthly_revenue
    from {{ ref('stg_orders') }}
    group by month(order_date)
)

select
    month_no,
    monthly_revenue,
    lag(monthly_revenue) over(order by month_no) as last_month_revenue,
    monthly_revenue - lag(monthly_revenue) over(order by month_no) as revenue_diff
from monthly_data;
