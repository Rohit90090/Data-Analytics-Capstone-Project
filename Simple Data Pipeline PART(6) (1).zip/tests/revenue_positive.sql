select *
from {{ ref('mart_monthly_revenue') }}
where monthly_revenue <= 0
